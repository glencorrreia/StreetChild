import React, { Component } from 'react';


class HomeBanner extends Component {
  render() {
    return (
      <section className="home_banner_area">
            <div className="banner_inner">
                <div className="container">
                    <div className="banner_content">
                        <p className="upper_text">Give a hand</p>
                        <h2>to make the better world</h2>
                        <p>
                        Charity begins on the street when you are homeless.
                        </p>
                       
                    </div>
                </div>
            </div>
        </section>
    );
  }
}

export default HomeBanner;
