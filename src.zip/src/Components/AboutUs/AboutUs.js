import React, { Component } from 'react';


class FeatureCause extends Component {
  render() {
    return (
      <section className="about_area section_gap_bottom">
      <br/><br/>
        <h2>Who are we ?</h2>
              <p>Sustainability, social equality and the environment are now business problems. And corporate leaders can't depend on governments to solve them..</p>
      <div className="container">
          <div className="row">	
              <div className="single_about row">
                  <div className="col-lg-6 col-md-12 text-center about_left">
                      <div className="about_thumb">
                          <img src="img/about-img.jpg" className="img-fluid" alt="" />
                      </div>
                  </div>
                  <div className="col-lg-6 col-md-12 about_right">
                      <div className="about_content">
                          <h2>
                              We are nonprofit team <br />
                                  and students who love to work for society 
                          </h2>
                          <p>
                         We believe that unless members of the civil society are involved proactively in the process of development, sustainable change will not happen. Believing in this principle of 'Civic Driven Change', Smile Foundation sensitises the civil society in order to make them partners in its mission.
                          </p>
                          
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </section>
    );
  }
}

export default FeatureCause;
