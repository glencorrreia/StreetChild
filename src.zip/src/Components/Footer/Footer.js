import React, { Component } from 'react';


class Footer extends Component {
  render() {
    return (
      <footer>
      <div className="footer-area">
          <div className="container">
              <div className="row section_gap">
                  <div className="col-lg-3 col-md-6 col-sm-6">
                      <div className="single-footer-widget tp_widgets">
                          <h4 className="footer_title large_title">Our Mission</h4>
                          <p>
                          Work as a catalyst in bringing sustainable change in the lives of underprivileged children, youth and women, with a life-cycle approach of development.
                          </p>
                          <p>
                          Enable the civil society across the world to engage proactively in the change process through the philosophy of civic driven change.                          </p>
                          <p>
                          Adopt highest standards of governance to emerge as a leading knowledge and technology driven, innovative and scalable international development organisation.                          </p>
                      </div>
                  </div>
                  
                  
                  <div className="offset-lg-1 col-lg-3 col-md-6 col-sm-6">
                      <div className="single-footer-widget tp_widgets">
                          <h4 className="footer_title">Contact Us</h4>
                          <div className="ml-40">
                              
  
                              <p className="sm-head">
                                  <span className="fa fa-phone"></span>
                                  Phone Number
                              </p>
                              <p>
                                   +91 9930637649 <br />
                                  +91 7775992669<br />
                                  +91 8286589954<br />
                                  +91 9769698133<br />
                              </p>
  
                              <p className="sm-head">
                                  <span className="fa fa-envelope"></span>
                                  Email
                              </p>
                              <p>
                                  yashmalhotra124@gmail.com <br />
                              </p>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  
  
  </footer>
    );
  }
}

export default Footer;
