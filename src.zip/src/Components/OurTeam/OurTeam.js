import React, { Component } from 'react';


class OurTeam extends Component {
  render() {
    return (
      <section className="causes_area">
      <div className="container">
          <div className="main_title">
              <h2>Our major causes</h2>
              <p>Creepeth called face upon face yielding midst is after moveth </p>
          </div>
          <div className="row">
              <div className="col-lg-4 col-md-6">
                  <div className="single_causes">
                      <h4>Give Donation</h4>
                      <img src="img/causes/c1.png" alt="" />
                      <p>
                          It you're. Was called you're fowl grass lesser land together waters beast darkness earth land whose male all moveth fruitful.
                      </p>
                  </div>
              </div>
              <div className="col-lg-4 col-md-6">
                  <div className="single_causes">
                      <h4>Give Inspiration</h4>
                      <img src="img/causes/c2.png" alt="" />
                      <p>
                          It you're. Was called you're fowl grass lesser land together waters beast darkness earth land whose male all moveth fruitful.
                      </p>
                  </div>
              </div>
              <div className="col-lg-4 col-md-6">
                  <div className="single_causes">
                      <h4>Become Bolunteer</h4>
                      <img src="img/causes/c3.png" alt="" />
                      <p>
                          It you're. Was called you're fowl grass lesser land together waters beast darkness earth land whose male all moveth fruitful.
                      </p>
                  </div>
              </div>
          </div>
      </div>
  </section>
    );
  }
}

export default OurTeam;
