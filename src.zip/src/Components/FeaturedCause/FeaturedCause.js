import React, { Component } from 'react';


class FeatureCasue extends Component {
  render() {
    return (
      <section className="features_causes">
            <div className="container">
                <div className="main_title">
                    <h2>Featured causes</h2>
                    <p>Our Vision and Belief </p>
                </div>
        
                <div className="row">
                    <div className="col-lg-4 col-md-6">
                        <div className="card">
                            <div className="card-body">
                                <figure>
                                    <img className="card-img-top img-fluid" src="img/features/fc1.jpg" alt="Card image cap" />
                                </figure>
                                <div className="card_inner_body">
                                    <h4 className="card-title">Education for every child</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-6">
                        <div className="card">
                            <div className="card-body">
                                <figure>
                                    <img className="card-img-top img-fluid" src="img/features/fc2.jpg" alt="Card image cap" />
                                </figure>
                                <div className="card_inner_body">
                                    <h4 className="card-title">Food for every Child</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-6">
                        <div className="card">
                            <div className="card-body">
                                <figure>
                                    <img className="card-img-top img-fluid" src="img/features/fc3.jpg" alt="Card image cap" />
                                </figure>
                                <div className="card_inner_body">
                                    <h4 className="card-title">Proper Nourishment of values to every child</h4></div>
                            </div>
                        </div> </div>
                </div>


                <div className="row">
                    <div className="col-lg-4 col-md-6">
                        <div className="card">
                            <div className="card-body">
                                <figure>
                                    <img className="card-img-top img-fluid" src="img/features/fc4.jpg" alt="Card image cap" />
                                </figure>
                                <div className="card_inner_body">
                                    <h4 className="card-title">Good future</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-6">
                        <div className="card">
                            <div className="card-body">
                                <figure>
                                    <img className="card-img-top img-fluid" src="img/features/fc5.jpg" alt="Card image cap" />
                                </figure>
                                <div className="card_inner_body">
                                    <h4 className="card-title">Good livelihood </h4> </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-6">
                        <div className="card">
                            <div className="card-body">
                                <figure>
                                    <img className="card-img-top img-fluid" src="img/features/fc6.jpg" alt="Card image cap" />
                                </figure>
                                <div className="card_inner_body">
                                    <h4 className="card-title">A better today , a better future</h4>                                    
                                </div>
                            </div>
                        </div>





                        
                    </div>
                </div>

            </div>
        </section>
    );
  }
}

export default FeatureCasue
