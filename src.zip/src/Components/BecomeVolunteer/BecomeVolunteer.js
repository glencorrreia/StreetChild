import React, { Component } from 'react';
import Register from '../Register/Register.js' ;
import ChildRegistration from '../ChildRegistration/ChildRegistration.js';


class BecomeVolunteer extends Component {

     constructor(props)
     {
     super(props)

 this.makeuserLoggedIn = this.makeuserLoggedIn.bind(this);

     }

     state = {

    isLoggedIn : true ,
 
    registerationtitle : "Become a volunteer",
    registrationExplaination :"Life's most persistent and urgent question is, 'What are you doing for others?",

    childRegisterationTitle : "Do The NeedFull",
    childegistrationExplaination :"Give, and it shall be given unto you; good measure, pressed down, and shaken together, and running over, shall men give into your bosom. For with the same measure that ye mete withal it shall be measured to you again.",


     }

     // make usser Logged In 
     makeuserLoggedIn()
     {         this.setState({

            isLoggedIn:true ,
           
         })
     }

    render() {
    return (
      <div className="cta-area section_gap overlay">
      <div className="container">
          <div className="row justify-content-center">
              <div className="col-lg-7">
                  <h1>{!this.state.isLoggedIn? this.state.registerationtitle:this.state.childRegisterationTitle}</h1>
                  <p>
                      {!this.state.isLoggedIn?this.state.registrationExplaination:this.state.childegistrationExplaination}
                  </p>
                  
              </div>
          </div>
  
          <br /><br /><br/>
          { !this.state.isLoggedIn ? <Register markLogin= {this.makeuserLoggedIn} />:<ChildRegistration />}
         
  
          
      </div>
  </div>
    );
  }
}

export default BecomeVolunteer;
