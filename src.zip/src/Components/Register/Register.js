import React, { Component } from 'react';
import './Register.css' ;

class Register extends Component {

 constructor(props)
 {
     super(props)
     
this.handleInputChange = this.handleInputChange.bind(this);
this.valiateFields = this.valiateFields.bind(this);
this.registerUser = this.registerUser.bind(this);
this.validateEmail = this.validateEmail.bind(this);
this.loginUser = this.loginUser.bind(this);
this.makeApiCall =this.makeApiCall.bind(this);

 }

 state = {


    enableLoader : false ,
    emailErrorMsg : false  ,
    PasswordErrorMsg : false  ,
    registrationError : false ,

}


handleInputChange(e)
{
this.setState({

[e.target.name] : e.target.value  , 

})
}

valiateFields()
{
    if(!this.state.email)
    {
        this.setState({
         emailErrorMsg:true ,
        })
        return false ;
    }

    if((this.state.email.length <=5))
    {
        this.setState({
            emailErrorMsg:true ,
           })
           return false ;
    }

    if(!this.validateEmail(this.state.email))
    {

        this.setState({
            emailErrorMsg:true ,
           })
           return false ;
    }

    if(!this.state.password || (this.state.password.length==0))
    {
        this.setState({
            PasswordErrorMsg:true ,
           })
           return false ;
    }


    this.setState({
        emailErrorMsg : false  ,
    PasswordErrorMsg : false  ,
    })

return true ;
}


registerUser()
{
    let localRef = this ;

    if(this.valiateFields())
    {
        // api call
        this.setState({
            enableLoader:true ,
        })

        this.makeApiCall(localRef,'http://127.0.0.1:8000/register/')

    }
}


makeApiCall(localRef,url)
{
    let header = new Headers({
        'Content-Type': 'application/json',
        "Accept": "application/json"
});
    fetch(url,
    {
        method: "POST",
        body: JSON.stringify({"username": localRef.state.email, "password": localRef.state.password})
    })
    .then(function(res){  return res.json(); })
    .then(function(data){

        localRef.setState({
            enableLoader:false ,
        })
     
        if(data["status"])
        {
        window.toast(data["validation"],5000);
        localRef.props.markLogin()
        }
        else{
            window.toast(data["validation"],5000);

        }



    })

 
}

loginUser()
{
    let localRef = this ;
    if(this.valiateFields())
    {
        // api call
        this.setState({
            enableLoader:true ,
        })

    this.makeApiCall(localRef,'http://127.0.0.1:8000/login/')
      }}



validateEmail(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}




  render() {
    return (
        <div className="my-container">
        <br /><br />
          <div className="my-row">
            <div className="input-group input-group-icon">
              <input value= {this.state.email} onChange = {this.handleInputChange} className="my-input" name = "email"   type="email" placeholder="Email Adress"/>
    {this.state.emailErrorMsg ?<p className="error_msg" >Please Enter valid Email ID</p>:<div></div> }
              <div className="input-icon"><i className="fa fa-envelope"></i></div>
            </div>
            <div className="input-group input-group-icon">
              <input value= {this.state.password} onChange = {this.handleInputChange} name = "password" className="my-input"  type="password" placeholder="Password"/>
              {this.state.PasswordErrorMsg ?<p className="error_msg">Please Enter valid Password</p>:<div></div> }
              <div className="input-icon"><i className="fa fa-key"></i></div>
            </div>
            {this.state.registrationError ?<p className="error_msg">Error in Signin , Please verify your Username or Password</p>:<div></div> }
            
    <div>{this.state.enableLoader?<img src="img/loader.gif" className="img-fluid" alt="" />:<div>
            <button onClick={this.registerUser} className="primary_btn yellow_btn rounded register_form_btn">join with us</button>
            <button  onClick={this.loginUser} className="primary_btn yellow_btn rounded register_form_btn">Login</button>
            </div>}</div>

          </div>
      </div>
        );
    }
  }
  
  export default Register;