import React, { Component } from 'react';


class MainCause extends Component {
  render() {
    return (
          
      <section className="causes_area">
      <div className="container">
          <div className="main_title">
              <h2>Our major causes</h2>
              <p>Creepeth called face upon face yielding midst is after moveth </p>
          </div>
          <div className="row">
              <div className="col-lg-4 col-md-6">
                  <div className="single_causes">
                      <h4>Give Donation</h4>
                      <img src="img/causes/c1.png" alt="" />
                      <p>
                      No one is useless in this world who lightens the burdens of another.
                      </p>
                  </div>
              </div>
              <div className="col-lg-4 col-md-6">
                  <div className="single_causes">
                      <h4>Give Inspiration</h4>
                      <img src="img/causes/c2.png" alt="" />
                      <p>
                      No one has ever become poor by giving.
                      </p>
                  </div>
              </div>
              <div className="col-lg-4 col-md-6">
                  <div className="single_causes">
                      <h4>Become Example</h4>
                      <img src="img/causes/c3.png" alt="" />
                      <p>
                      You can't make me be nice. You can't make me be good. You can't make me believe.But your example, your kindness, your patience and love will affect me perhaps enough that eventually I may choose to do those things.
                      </p>
                  </div>
              </div>
          </div>
      </div>
  </section>
    );
  }
}

export default MainCause;
