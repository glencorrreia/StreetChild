import React, { Component } from 'react';
import './ChildRegistration.css' ;
import ImagePicker from 'react-image-picker'
import 'react-image-picker/dist/index.css'
import { ifError } from 'assert';



class ChildRegistration extends Component {



    constructor(props)
    {
        super(props)
        
   this.handleInputChange = this.handleInputChange.bind(this);
   this.valiateFields = this.valiateFields.bind(this);
   this.registerChild = this.registerChild.bind(this);
   
    }
   
    state = {
        enableLoader : false ,
         locationError : false  , 
         timeError : false  ,
          ageError : false , 
           photoError : false ,
            nameError : false ,
            mesaage : "" ,
            showMessage: false ,
            registerationError : false ,
   
   }
   
   
   handleInputChange(e)
   {

    if(e.target.name =="childPhoto"||e.target.name =="birthMark")
    {
        this.setState({
   
            [e.target.name] : e.target.files[0] , 
            
            })
        return
    }
   this.setState({
   
   [e.target.name] : e.target.value  , 
   
   })
   }
   
   valiateFields()
   {
       

    
    if(!this.state.name || (this.state.name.length==0))
    {

        this.setState({
            nameError:true ,
        })

        return false
    }

    if(!this.state.age || (this.state.age.length==0))
    {
        this.setState({
            ageError:true ,
        })

        return false
    }


    if(!this.state.location || (this.state.location.length==0))
    {
        this.setState({
            locationError:true ,
        })

        return false
    }


    if(!this.state.time)
    {
        this.setState({
            timeError:true ,
        })

        return false
    }


    if(!this.state.childPhoto)
    {
        this.setState({
            photoError:true ,
        })

        return false
    }



    return true ;

}
   
   // Register Child Here
   registerChild()
   {
      let localRef = this ; 
    this.setState({
        nameError:false ,
        ageError:false ,
        locationError:false ,
        timeError:false ,
        photoError:false ,
        registerationError:false ,

       })
       if(this.valiateFields())
       {
          
       // api call
       let formData = new FormData();    //formdata object

       for (var key in this.state) {
        if (this.state.hasOwnProperty(key)) {
            formData.append(key , this.state[key]);
        }
    }
          
        this.setState({

            enableLoader:true 

        })
       
       fetch("http://127.0.0.1:8000/child/register/",
        {
            method: "POST",
            header : {'content-type': 'multipart/form-data',"credentials": 'include'} ,
            body: formData
        })
        .then(function(res){  return res.json(); })
        .then(function(data){
            console.log(data)
            localRef.setState({enableLoader:false})

            if(data["status"])
            {
            localRef.setState({
                mesaage:data["message"]
            })
            window.toast("ThankYou For Your Time . One life id successfully saved",5000);
        }
        else{
            window.toast(data["Validation"],5000);
        }
            
        })

       

       }
       else{
 
        window.toast("Please verify the form again",5000);


         this.setState({
             registerationError:true ,
         })
       }
   }
    


  render() {
    return ( <div className="my-container">
    <br /><br />
      <div className="my-row">
      {/* Name Of Child  */}
        <div className="input-group input-group-icon">
        <p className="form_label">Enter Child Name *</p><br/>
          <input className="my-input" name="name" onChange={this.handleInputChange} type="text" placeholder="Child Name"/>
         { this.state.nameError ?  <p className="error_msg" style={{color:'red !important'}}>Please Enter valid Child Name</p> : <div></div>}
        </div>

          {/* Age Of Child */}
          <div className="input-group input-group-icon">
          <p className="form_label">Enter Child Age * (Put approximate age if unknow )</p><br/>
          <input className="my-input"  name="age" onChange={this.handleInputChange}   type="number" placeholder="Child Age"/>
          { this.state.ageError ?  <p className="error_msg" style={{color:'red !important'}}>Please Enter valid Child Age</p> : <div></div>}
        </div>


          {/* Child DOB */}
          <div className="input-group input-group-icon">
          <p className="form_label">Enter Child Date Of Birth</p><br/>
          <input className="my-input"  name="dob" onChange={this.handleInputChange}  type="date" placeholder="DOB"/>
        </div>

          {/* Child Category */}
          <div className="input-group input-group-icon">
          <p className="form_label">Select Child Category *</p> <br/>
          <select name="carlist"  name="category" onChange={this.handleInputChange}  form="carform">
                <option value="1">Orphan</option>
                <option value="2">Street</option>
                <option value="3">Lost</option>
        </select>
        </div>


         {/* Child Gender */}
         <div className="input-group input-group-icon">
         <p className="form_label"  >Select Child Gender *</p> <br/>
          <select name="carlist"  name="gender" onChange={this.handleInputChange} form="carform">
                <option value="1">Male</option>
                <option value="2">Female</option>
                <option value="3">Other</option>
            </select>
        </div>

    {/* Loction Of Child  */}
    <div className="input-group input-group-icon">
    <p className="form_label">Enter child found Location *</p> <br/>
          <input className="my-input"  name="location" onChange={this.handleInputChange}  type="text" placeholder="Location of child"/>
          { this.state.locationError ?   <p className="error_msg"  style={{color:'red !important'}}>Please Enter valid Child Location *</p> : <div></div>}
        </div>


        {/* Child Found Time  */}
        <div className="input-group input-group-icon">
        <p className="form_label">Enter child found time *</p> <br/>
          <input className="my-input"  name="time" onChange={this.handleInputChange}  type="time" placeholder="Child Found Time"/>
          { this.state.timeError ?  <p className="error_msg"  style={{color:'red !important'}}>Please Enter valid Time *</p> : <div></div>}
        </div>

        {/* Does child go to school */}
          <div className="input-group input-group-icon">
          <p className="form_label">Does the child go to school ? </p><br/>
          <input type="radio"  name="school" onChange={this.handleInputChange} value="t"  /> <p className="form_label">Yes</p><br />
            <input type="radio"  name="school" onChange={this.handleInputChange} value="f" className="form_label" checked/> <p className="form_label">No</p><br/>
     </div>

        {/* Child School Name */}
        <div className="input-group input-group-icon">
        <p className="form_label">Enter school name</p> <br/>
                <input className="my-input"  name="schoolDes" onChange={this.handleInputChange}  type="text" placeholder="School Description"/>
                </div>

        {/* Does child parents work ? */}
        <div className="input-group input-group-icon">
          <p className="form_label">Does child parents work ?</p><br/>
            <input type="radio"  name="parentsWork" onChange={this.handleInputChange} value="t"  /> <p className="form_label">Yes</p><br />
            <input type="radio"  name="parentsWork" onChange={this.handleInputChange} value="f" className="form_label" checked/> <p className="form_label">No</p><br/>
        </div>

         {/* Location of parents work place  */}
         <div className="input-group input-group-icon">
         <p className="form_label">Enter parents work location </p> <br/>
                <input className="my-input"  name="parentsWorkLocation" onChange={this.handleInputChange}  type="text" placeholder="Parents Work Place"/>
                </div>

                 {/* Parent work Income  */}
        <div className="input-group input-group-icon">
        <p className="form_label">Enter parents income (Monthly)</p> <br/>
                <input className="my-input"   name="parentsIncome" onChange={this.handleInputChange} type="number" placeholder="Income"/>
                </div>

          {/* Child Photo */}
          <div className="input-group input-group-icon form_label">
          <p className="form_label">Enter valid Child Photo *</p>
          <input type="file" name="childPhoto" onChange={this.handleInputChange} accept="image/*" />

          { this.state.photoError ?   <p className="error_msg"  style={{color:'red !important'}}>Please Enter valid Child Photo</p> : <div></div>}
        </div>


          {/* Birth Mark Photo */}
          <div className="input-group input-group-icon form_label">
          <p className="form_label">EnterChild Birth Mark Photo</p>
          <input type="file"   name="birthMark" onChange={this.handleInputChange} accept="image/*" />
        </div>
       

        {this.state.showMessage ?   <div className="message_des">
        <div className="msg_logo"><img src ="img/msg.gif" width ="100px" height="100px"/></div>
       <div className="msg_desc">
            <p>{this.state.mesaage}</p>
        </div>
        </div>:<div></div>}

        <div>{this.state.enableLoader?<img src="img/loader.gif" className="img-fluid" alt="" />:
        <div><button onClick={this.registerChild} className="primary_btn yellow_btn rounded register_form_btn">Save a Life</button></div>}</div>
        { this.state.registerationError ?   <p className="error_msg"  style={{color:'red !important'}}>Please enter all mandatory fields in above form and clear the errors in above form</p> : <div></div>}
      </div>
  </div> );
}
}

export default ChildRegistration;