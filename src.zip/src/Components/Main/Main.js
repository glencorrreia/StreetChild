import React, { Component } from 'react';
import './Main.css';
import NavBar from '../Navbar/Navbar.js'
import HomeBanner from '../HomeBanner/HomeBanner.js'
import MainCause from '../MainCause/MainCause.js'
import FeatureCause from '../FeaturedCause/FeaturedCause.js'
import BecomeVolunteer from '../BecomeVolunteer/BecomeVolunteer.js'
import AboutUs from '../AboutUs/AboutUs.js'
import Gallery from '../Gallery/Gallery.js'
import Footer from '../Footer/Footer.js'


class Main extends Component {
  render() {
    return (
        <div>
                   <NavBar />
                   <HomeBanner />
                   <MainCause />
                   <FeatureCause />
                   <BecomeVolunteer />
                   <Gallery />
                   <AboutUs />
                   <Footer />
        </div>
    );
  }
}

export default Main;
