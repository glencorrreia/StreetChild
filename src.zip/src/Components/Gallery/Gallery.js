import React, { Component } from 'react';
import './Gallery.css' ;

class Gallery extends Component {


  numberOfImages = 20 ;  
  state = {imageData : [] , } ;


  constructor(props)
  {
      super(props)
 this.createImageData = this.createImageData.bind(this);
  }

  componentDidMount()
  {
  this.createImageData()
  }
  
  createImageData()
  {
     let data = []
      for(let i =1;i<=this.numberOfImages;i++)
      {
          data.push(i);
      }

      this.setState({
          imageData : data ,
      })
  }

  render() {
    return (
        <div id="gallery">
            <br/><br/>
            <div className="main_title">
                    <h2>Gallery</h2>
                    <p>10 minutes of your time for this childrens </p>
                </div>
        <div className="container">
        <div className="row">
          { this.state.imageData.map((value)=>(
            <div className="col-md-4 col-sm-4 padcol ">
                <div className="col-3">
                    <a href="#"><img src={"img/gallery/"+value+".jpg"} width ="100%" className="img-responsive" alt="" />
                        <div className="col-pic">
                        </div></a>
                </div>
            </div>
          ))};
        </div>
         </div> 
         </div>
    );
  }
}

export default Gallery;