import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Main from './Components/Main/Main'

class App extends Component {


  constructor(props)
  {
    super(props)

  }

state= {
    message : "",
    time : 0,
}


 componentDidMount()
 {
   let localRef = this ;
  window.toast = function(message,time) {
   localRef.setState({
    message:message,
    time : time ,

   },()=>{



    var x = document.getElementById("toast")
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show", ""); },localRef.state.time);
    
   })
}
 }


  render() {
    return (
      <div className="App">
       <Main />
       <div id="toast"><div id="img"><i class="material-icons">
        announcement
</i></div><div id="desc">{this.state.message}</div></div>

      </div>
    );
  }
}

export default App;
