from django.contrib import admin
from .models import *
# Register your models here.






admin.site.register(PendingUsers);
admin.site.register(AuthorizedUsers);
admin.site.register(ChildGender);
admin.site.register(ChildCategory);
admin.site.register(PoliceCriminalRecord);
admin.site.register(LostAndFoundRecords);
admin.site.register(RegisteredChildren);