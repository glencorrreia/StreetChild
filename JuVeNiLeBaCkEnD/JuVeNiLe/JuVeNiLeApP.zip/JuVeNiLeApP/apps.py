from django.apps import AppConfig


class JuvenileappConfig(AppConfig):
    name = 'JuVeNiLeApP'
