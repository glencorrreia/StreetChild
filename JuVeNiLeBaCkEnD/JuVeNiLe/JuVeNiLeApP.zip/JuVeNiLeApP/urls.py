
from django.conf.urls import url
from .views import *


urlpatterns =[
    url(r'^login/$', loginView),
    url(r'^logout/$', logoutView),
    url(r'^register/$', register_user),
    url(r'^child/register/$', register_child),

]